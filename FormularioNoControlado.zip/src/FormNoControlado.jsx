import { useRef, useState } from "react"

const FormNoControlado = () => {

const formulario = useRef(null)
    let [check, setBoolean] = useState()
    let campovacio = ""
    const handleSubmit = e => {
        console.log("click")
        e.preventDefault()
        const datos = new FormData(formulario.current)
        console.log(...datos.entries())

        const objetoDatos = Object.fromEntries([...datos.entries()])

        console.log(objetoDatos)

        const {nombre_tarea, Descripcion, Estado} = objetoDatos

        if (!nombre_tarea.trim()) {
            setBoolean(check === true)
            campovacio = "Nombre"
        }else if (!Descripcion.trim()) {
            setBoolean(check === true)
            campovacio = "Descripción"
        }else if(!Estado.trim()) {
            setBoolean(check === true)
            campovacio = "Estado"
        }else{
            setBoolean(false)
        }

        console.log(campovacio)
        check ? console.log("Mensaje Enviado"):console.log(`ERROR! Rellene el campo ${campovacio}`)
    }

    return (
        <>
            <form onSubmit={handleSubmit} ref={formulario}>
                <input 
                    name="nombre_tarea" 
                    placeholder="Nombre de la tarea" 
                    type="text"
                    className="form-control mb-2"
                />
                <textarea
                    name="Descripcion"
                    placeholder="Introduce la descripción de la tarea"
                    className="form-control mb-2"
                />
                <select
                    name="Estado"
                    className="form-control mb-2"
                >
                    <option value="">Seleccione un Valor</option>
                    <option value="pendiente">Pendiente</option>
                    <option value="completada">Completada</option>
                </select>
                <button type="submit" className="btn btn-primary">Añadir</button>
            </form>
        </>
    );
}

export default FormNoControlado;
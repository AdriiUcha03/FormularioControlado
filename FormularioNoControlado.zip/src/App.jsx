import { useState } from 'react'
import FormNoControlado from './FormNoControlado'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div className='container'>
          <h1>Formulario no Controlado1</h1>
          <FormNoControlado/>
      </div>
        
    </>
  )
}

export default App
